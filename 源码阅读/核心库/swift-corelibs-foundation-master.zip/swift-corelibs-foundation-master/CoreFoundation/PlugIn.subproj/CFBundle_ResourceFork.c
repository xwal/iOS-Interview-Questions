/*      CFBundle_ResourceFork.c
        Copyright (c) 1999-2017, Apple Inc.  All rights reserved.
        Responsibility: Tony Parker
*/

#include <CoreFoundation/CFBundle.h>

